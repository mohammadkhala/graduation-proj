<?php

namespace App\Http\Controllers\Admin\Report;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class StudentAcademicHistoryController extends Controller
{
    //
}
