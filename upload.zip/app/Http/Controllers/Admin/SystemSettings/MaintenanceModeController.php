<?php

namespace App\Http\Controllers\Admin\SystemSettings;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class MaintenanceModeController extends Controller
{
    
}
